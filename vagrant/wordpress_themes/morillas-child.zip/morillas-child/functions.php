<?php
spl_autoload_register(function ($className) {
    $className = str_replace("\\", DIRECTORY_SEPARATOR, $className);
    if (is_file(dirname(__FILE__) . DIRECTORY_SEPARATOR . 'classes' . DIRECTORY_SEPARATOR . $className . '.php')) {
        require_once dirname(__FILE__) . DIRECTORY_SEPARATOR . 'classes' . DIRECTORY_SEPARATOR . $className . '.php';
    } else if (is_file(dirname(__FILE__) . DIRECTORY_SEPARATOR . 'classes' . DIRECTORY_SEPARATOR . 'extras' . DIRECTORY_SEPARATOR . $className . '.php')) {
        require_once dirname(__FILE__) . DIRECTORY_SEPARATOR . 'classes' . DIRECTORY_SEPARATOR . 'extras' . DIRECTORY_SEPARATOR . $className . '.php';
    }
});

require_once(dirname(__FILE__).DIRECTORY_SEPARATOR."..".DIRECTORY_SEPARATOR."morillas".DIRECTORY_SEPARATOR."functions.php");

$mt = MorillasThemeChild::singleton();
$mt->init();

// Place to call $mt->addMenuLocations

// Place to call $mt->addSocialMediaOptions

// Load jQuery
$jQueryVersion = '3.2.1';
enqueue_external_lib('jquery', $jQueryVersion, !ON_FOOTER);

// Loads morillas.css
enqueue_child_style('morillas.css');
enqueue_admin_child_style('admin/admin.css');

// Load script from parent theme
enqueue_parent_script('cookies.js');
enqueue_parent_script('svg.js');
enqueue_parent_script('back-to-top.js');

// Custom login page
custom_login_page('Login page Title');
