<?php
class MorillasThemeChild extends MorillasTheme
{
}
