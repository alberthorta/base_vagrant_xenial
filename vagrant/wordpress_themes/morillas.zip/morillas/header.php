<!DOCTYPE html>
<html <?php language_attributes(); ?>>
	<head>


        <?php if (get_option('google-tag-manager') != ''){?>

            <!-- Google Tag Manager -->
            <script>
                (function(w,d,s,l,i){
                    w[l]=w[l]||[];
                    w[l].push({
                        'gtm.start': new Date().getTime(),
                        event:'gtm.js'
                    });
                    var f=d.getElementsByTagName(s)[0],
                    j=d.createElement(s),
                        dl=l!='dataLayer'?'&l='+l:'';
                    j.async=true;
                    j.src= 'https://www.googletagmanager.com/gtm.js?id='+i+dl;
                    f.parentNode.insertBefore(j,f);
                })(window,document,'script','dataLayer','<?php echo get_option('google-tag-manager'); ?>');
            </script>
            <!-- End Google Tag Manager -->

        <?php }else if ((get_option('google-tag-manager') == '') && (get_option('google-analytics') != '')){ ?>

            <!-- Global site tag (gtag.js) - Google Analytics -->
            <script async src="https://www.googletagmanager.com/gtag/js?id=<?php echo get_option('google-analytics'); ?>"></script>
            <script>
                window.dataLayer = window.dataLayer || [];
                function gtag(){dataLayer.push(arguments);}
                gtag('js', new Date());

        24        gtag('config', '<?php echo get_option('google-analytics'); ?>');
            </script>

        <?php } ?>

		<meta name="viewport" content="width=device-width, initial-scale=1,maximum-scale=1, user-scalable=no">
		<meta charset="<?php bloginfo( 'charset' ); ?>" />
		<title><?php wp_title(); ?></title>
		<link rel="apple-touch-icon" sizes="57x57" href="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/image/favicon/apple-icon-57x57.png">
		<link rel="apple-touch-icon" sizes="60x60" href="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/image/favicon/apple-icon-60x60.png">
		<link rel="apple-touch-icon" sizes="72x72" href="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/image/favicon/apple-icon-72x72.png">
		<link rel="apple-touch-icon" sizes="76x76" href="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/image/favicon/apple-icon-76x76.png">
		<link rel="apple-touch-icon" sizes="114x114" href="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/image/favicon/apple-icon-114x114.png">
		<link rel="apple-touch-icon" sizes="120x120" href="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/image/favicon/apple-icon-120x120.png">
		<link rel="apple-touch-icon" sizes="144x144" href="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/image/favicon/apple-icon-144x144.png">
		<link rel="apple-touch-icon" sizes="152x152" href="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/image/favicon/apple-icon-152x152.png">
		<link rel="apple-touch-icon" sizes="180x180" href="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/image/favicon/apple-icon-180x180.png">
		<link rel="icon" type="image/png" sizes="192x192"  href="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/image/favicon/android-icon-192x192.png">
		<link rel="icon" type="image/png" sizes="32x32" href="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/image/favicon/favicon-32x32.png">
		<link rel="icon" type="image/png" sizes="96x96" href="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/image/favicon/favicon-96x96.png">
		<link rel="icon" type="image/png" sizes="16x16" href="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/image/favicon/favicon-16x16.png">
		<meta name="msapplication-TileColor" content="#ffffff">
		<meta name="msapplication-TileImage" content="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/image/favicon/ms-icon-144x144.png">
		<meta name="theme-color" content="#ffffff">
	    <?php wp_head(); ?>
    </head>
	
	<body>
        <?php if (get_option('google-tag-manager') != ''){?>
            <!-- Google Tag Manager (noscript) -->
            <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=<?php echo get_option('google-tag-manager'); ?>"
                              height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
            <!-- End Google Tag Manager (noscript) -->
        <?php } ?>

		<header class="main-header main-gradient" id="wrap">
			<a href="<?php echo get_home_url(); ?>" class="logo-header">
                <?php

                    $var_logo_lang = get_option('logo-header-url-'.ICL_LANGUAGE_CODE);
                    $wpml_options = get_option( 'icl_sitepress_settings' );
                    $default_lang = $wpml_options['default_language'];

                if ( $var_logo_lang != '' ){ ?>
                    <img id="logo-header" src="<?php echo esc_attr( get_option('logo-header-url-'.ICL_LANGUAGE_CODE) ); ?>" alt="<?php echo bloginfo('name'); ?>" class="logo" />
                <?php } else { ?>
                    <img id="logo-header" src="<?php echo esc_attr( get_option('logo-header-url-'.$default_lang) ); ?>" alt="<?php echo bloginfo('name'); ?>" class="logo" />
                <?php } ?>

            </a>
			<nav>
				<?php wp_nav_menu( array('container' => false, 'theme_location' => 'header-menu', 'menu_class' => 'menu header' )); ?>
			</nav>
		</header>