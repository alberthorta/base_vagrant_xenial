function Filter(name, base_class, with_total) {
    this.name = name;
    this.base_class = base_class;
    this.with_total = with_total;
    this.filters = {};
    this.filterObjects = [];
    this.url = window.location.href;
    if( typeof document.filters == "undefined" ) document.filters = {};
    document.filters[name] = this;
}

Filter.prototype.addFilterObject = function(name) {
    this.filterObjects.push(name);
};

Filter.prototype.addFilter = function (name, value) {
    if( value == undefined ) value = null;
    if( this.filters[name] === undefined ) this.filters[name] = value;
};

Filter.prototype.setValue = function(name, value) {
    if( this.filters[name] !== undefined ) this.filters[name] = value;
};

Filter.prototype.getValue = function(name) {
    return this.filters[name];
};

Filter.prototype.send = function (onload) {
    var xhttp = new XMLHttpRequest();
    xhttp.open("POST", this.url);
    xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    xhttp.onload = function() {
        response = {};
        if(xhttp.status === 200) {
            var response = JSON.parse(xhttp.response);
            (onload.bind(xhttp))(response);
        }
        return response;
    };
    var data = Object.assign({},
        {filter_data: JSON.stringify(this.filters)},
        { filter_name: this.name, mfilters: 1, filter_objects: JSON.stringify(this.filterObjects), base_class: this.base_class, with_total: this.with_total
    });
    xhttp.send(Object.keys(data).map(function(k) {
        return encodeURIComponent(k) + '=' + encodeURIComponent(data[k])
    }).join('&'));
};

if (!Object.assign) {
    Object.defineProperty(Object, 'assign', {
        enumerable: false,
        configurable: true,
        writable: true,
        value: function(target) {
            'use strict';
            if (target === undefined || target === null) {
                throw new TypeError('Cannot convert first argument to object');
            }

            var to = Object(target);
            for (var i = 1; i < arguments.length; i++) {
                var nextSource = arguments[i];
                if (nextSource === undefined || nextSource === null) {
                    continue;
                }
                nextSource = Object(nextSource);

                var keysArray = Object.keys(Object(nextSource));
                for (var nextIndex = 0, len = keysArray.length; nextIndex < len; nextIndex++) {
                    var nextKey = keysArray[nextIndex];
                    var desc = Object.getOwnPropertyDescriptor(nextSource, nextKey);
                    if (desc !== undefined && desc.enumerable) {
                        to[nextKey] = nextSource[nextKey];
                    }
                }
            }
            return to;
        }
    });
}