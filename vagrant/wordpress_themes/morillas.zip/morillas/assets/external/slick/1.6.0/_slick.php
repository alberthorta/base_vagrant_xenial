<?php
$dependencies = ['jquery'];

if($autoload_dependencies) {
    //wp_deregister_script('jquery');
    foreach($dependencies as $dependency) {
        if(!wp_script_is($dependency, 'registered')) {
            enqueue_external_lib($dependency, 'last', true);
        }
    }
}

enqueue_external_lib_script('slick', "slick/1.6.0/js/slick.js", $dependencies, '1.6.0', $on_footer);
enqueue_external_lib_css('slick', "slick/1.6.0/css/slick.css");