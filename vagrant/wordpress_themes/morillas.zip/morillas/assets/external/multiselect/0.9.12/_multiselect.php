<?php
$dependencies = ['jquery'];

if($autoload_dependencies) {
    //wp_deregister_script('jquery');
    foreach($dependencies as $dependency) {
        if(!wp_script_is($dependency, 'registered')) {
            enqueue_external_lib($dependency, 'last', true);
        }
    }
}

enqueue_external_lib_script('multiselect', "multiselect/0.9.12/js/jquery.multi-select.js", $dependencies, '0.9.12', $on_footer);
enqueue_external_lib_css('multiselect', "multiselect/0.9.12/css/multi-select.css");