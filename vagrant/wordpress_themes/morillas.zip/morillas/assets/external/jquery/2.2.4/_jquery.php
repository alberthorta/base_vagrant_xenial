<?php
$dependencies = [];

if($autoload_dependencies) {
    foreach($dependencies as $dependency) {
        if(!wp_script_is($dependency, 'registered')) {
            enqueue_external_lib($dependency, 'last', true);
        }
    }
}

enqueue_external_lib_script('jquery', "jquery/2.2.4/jquery-2.2.4.js", $dependencies, '2.2.4', $on_footer);