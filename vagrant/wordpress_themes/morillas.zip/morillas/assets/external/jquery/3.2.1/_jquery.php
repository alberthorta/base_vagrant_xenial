<?php
$dependencies = [];

if($autoload_dependencies) {
    foreach($dependencies as $dependency) {
        if(!wp_script_is($dependency, 'registered')) {
            enqueue_external_lib($dependency, 'last', true);
        }
    }
}

enqueue_external_lib_script('jquery', "jquery/3.2.1/jquery-3.2.1.js", $dependencies, '3.2.1', $on_footer);