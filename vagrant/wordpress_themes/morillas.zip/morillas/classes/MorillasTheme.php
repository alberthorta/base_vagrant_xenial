<?php

class MorillasTheme
{
    static $instance = null;

    const PARENT = 0;
    const CHILD = 1;

    protected $_parent_path = null;
    protected $_child_path = null;
    protected $_global_variables = [];

    protected function __construct() {
        spl_autoload_register(function ($className) {
            if ( is_file(dirname(__FILE__) .DIRECTORY_SEPARATOR. $className . '.php') ) {
                require_once dirname(__FILE__) .DIRECTORY_SEPARATOR. $className . '.php';
            }
        });

        $this->_parent_path = realpath(dirname(__FILE__).DIRECTORY_SEPARATOR."..".DIRECTORY_SEPARATOR);
        $this->_child_path = realpath(dirname(__FILE__).DIRECTORY_SEPARATOR."..".DIRECTORY_SEPARATOR."..".DIRECTORY_SEPARATOR."morillas-child".DIRECTORY_SEPARATOR);
    }

    public static function singleton() {
        return static::$instance === null ? static::$instance = new static() : static::$instance;
    }

    public function parentPath($file = null) {
        return $this->_parent_path.($file===null?"":DIRECTORY_SEPARATOR.$file);
    }

    public function uploadsPath($file = null) {
        return $this->_parent_path.DIRECTORY_SEPARATOR.'..'.DIRECTORY_SEPARATOR.'..'.DIRECTORY_SEPARATOR.'uploads'.($file===null?"":DIRECTORY_SEPARATOR.$file);
    }

    public function parentUrl($file = null) {
        return get_template_directory_uri().str_replace(DIRECTORY_SEPARATOR, '/', ($file===null?"":DIRECTORY_SEPARATOR.$file));
    }

    public function childPath($file = null) {
        return $this->_child_path.($file===null?"":DIRECTORY_SEPARATOR.$file);
    }

    public function childUrl($file = null) {
        return get_stylesheet_directory_uri().str_replace(DIRECTORY_SEPARATOR, '/', ($file===null?"":DIRECTORY_SEPARATOR.$file));
    }

    public function loadParentShortcodes() {
        $path = $this->parentPath().DIRECTORY_SEPARATOR."shortcodes";
        $d = @dir($path);
        if($d === false) return;
        $shortcodes = [];
        while(false !== ($entry = $d->read())) {
            if(is_file($path.DIRECTORY_SEPARATOR.$entry)) {
                if(stristr($entry,'.php') !== false) {
                    $shortcodes[] = $path.DIRECTORY_SEPARATOR.$entry;
                }
            }
        }
        sort($shortcodes);
        foreach($shortcodes as $shortcode) {
            require_once($shortcode);
        }
        $d->close();
    }

    public function loadChildShortcodes() {
        $path = $this->childPath().DIRECTORY_SEPARATOR."shortcodes";
        $d = @dir($path);
        if($d === false) return;
        $shortcodes = [];
        while(false !== ($entry = $d->read())) {
            if(is_file($path.DIRECTORY_SEPARATOR.$entry)) {
                if(stristr($entry,'.php') !== false) {
                    $shortcodes[] = $path.DIRECTORY_SEPARATOR.$entry;
                }
            }
        }
        sort($shortcodes);
        foreach($shortcodes as $shortcode) {
            require_once($shortcode);
        }
        $d->close();
    }

    public function fileUrl($file) {
        if(file_exists($this->childUrl(trim($file,'/')))) {
            return $this->childUrl(trim($file,'/'));
        } else {
            return $this->parentUrl(trim($file,'/'));
        }
    }

    public function filePath($file) {
        if(file_exists($this->childPath(trim($file,'/')))) {
            return $this->childPath(trim($file,'/'));
        } else {
            return $this->parentPath(trim($file,'/'));
        }
    }

    protected function requireOnceFrom($file, $where = self::PARENT) {
        require_once($where===self::PARENT ? $this->parentPath($file) : $this->childPath($file));
    }

    protected function includeFrom($file, $where = self::PARENT) {
        include($where===self::PARENT ? $this->parentPath($file) : $this->childPath($file));
    }

    public function requireOnceFromParent($file) {
        $this->requireOnceFrom($file, self::PARENT);
    }

    public function requireOnceFromChild($file) {
        $this->requireOnceFrom($file, self::CHILD);
    }

    public function includeFromParent($file) {
        $this->requireOnceFrom($file, self::PARENT);
    }

    public function includeFromChild($file) {
        $this->requireOnceFrom($file, self::CHILD);
    }

    public function init() {
        add_action('admin_menu', function() {
            add_menu_page('Theme Options', 'Theme Options', 'manage_options', 'theme-options', MorillasTemplate::renderTemplate('themeOptionsSettings.template.php'));
            add_submenu_page('theme-options', 'Cookies', 'Cookies', 'manage_options', 'theme-op-cookies', MorillasTemplate::renderTemplate('themeSettingsPage.template.php'));
            add_submenu_page('theme-options', 'Google Analytics', 'Google Analytics', 'manage_options', 'theme-op-google', MorillasTemplate::renderTemplate('themeOptionsGoogle.template.php'));
        });
        add_action('admin_init', function() { register_setting( 'theme-options-fields', 'logo-header-url-'.ICL_LANGUAGE_CODE ); });
        $this->requireOnceFromParent("functions.php");
        $this->loadCPTS();
    }

    public function addMenuLocations($addMenu){
        add_action('init', function () use ($addMenu) {
            if (!empty($addMenu)) register_nav_menus($addMenu);
        });
    }

    public function loadCPTS() {
        $d = @dir(MorillasTheme::singleton()->childPath("cpt"));
        $cpt = [];
        if($d) {
            while (false !== ($entry = $d->read())) {
                if (is_file(MorillasTheme::singleton()->childPath("cpt" . DIRECTORY_SEPARATOR . $entry))) {
                    $cpt[] = "cpt" . DIRECTORY_SEPARATOR . $entry;
                }
            }
            $d->close();
            sort($cpt);
            foreach ($cpt as $file) {
                MorillasTheme::singleton()->requireOnceFromChild($file);
            }
        }
    }

    public function __get($name)
    {
        return $this->_global_variables[$name];
    }

    public function __set($name, $value)
    {
        $this->_global_variables[$name] = $value;
    }
}

