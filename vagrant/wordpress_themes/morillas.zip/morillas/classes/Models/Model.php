<?php

namespace Models;

class Model
{
    protected $table = "wp_posts";
    protected $meta_table = "wp_postmeta";
    protected $base_fields = ['ID', 'post_name', 'post_type'];
    protected $render_value = 'post_name';
    protected $id = 'ID';
    protected $meta_id = 'post_id';
    protected $post_type = 'post';
    protected $fields = [];
    protected $meta_fields = [];
    protected $data = [];
    protected $mqb;

    static function fake($list)
    {
        $model = new static();
        $model->table = "";
        $model->meta_table = "";
        $model->base_fields = array_unique(array_keys($list));
        $model->id = current($model->base_fields);
        $model->meta_id = "";
        $model->post_type = null;
        $model->data = $list;
        $model->mqb = null;
        $model->render_value = $model->id;

        return $model;
    }

    public function __construct($options = [])
    {
        $this->mqb = new QueryBuilder();
        $this->mqb->built_model = get_called_class();
        $this->mqb->setTable($this->table);
        if (!empty($this->meta_fields)) {
            $meta_table = new QueryBuilder();
            $meta_table->setTable($this->meta_table, 'pm');
            $meta_table->field('pm.' . $this->meta_id, $this->id);
            $meta_table->group('pm.' . $this->meta_id);
            foreach ($this->meta_fields as $field) {
                $meta_table->field("MAX(CASE WHEN pm.meta_key = '" . $field . "' THEN pm.meta_value ELSE NULL END)", $field);
                $this->mqb->field("meta_table." . $field, $field);
            }
            $this->mqb->join($meta_table, ConditionBuilder::build(["=", $this->table . "." . $this->id, "meta_table." . $this->id]), QueryBuilder::LEFT_JOIN, "meta_table");
        }
        $fields = array_merge($this->base_fields, $this->fields);
        foreach ($fields as $field) $this->mqb->field($this->table . "." . $field);
        if ($this->post_type !== null) $this->mqb->where(ConditionBuilder::build(["=", $this->table . ".post_type", "'" . $this->post_type . "'"]));
    }

    public function getQueryBuilder()
    {
        return $this->mqb;
    }

    public function setData($data)
    {
        $lowercase_data = [];
        foreach ($data as $key => $value) {
            $lowercase_data[strtolower($key)] = $value;
        }
        $this->data = $lowercase_data;
    }

    public function getTable()
    {
        return $this->table;
    }


    public function getId()
    {
        return $this->id;
    }

    public static function find($ids)
    {
        if (!is_array($ids)) {
            $ids = [$ids];
        }

        $params = func_get_args();
        array_shift($params);
        $mm = new static($params);
        $mm->mqb->where(ConditionBuilder::build(["IN", $mm->table . "." . $mm->id, "(" . implode(", ", $ids) . ")"]));
        $sql = $mm->mqb->sql();

        global $wpdb;
        $results = $wpdb->get_results($sql, ARRAY_A);

        if (count($results) === 0) return null;
        else if (count($results) === 1) {
            $mm->setData($results[0]);
            return $mm;
        } else {
            $final_result = [];
            foreach ($results as $result) {
                $obj = new static($params);
                $obj->setData($result);
                $final_result[] = $obj;
            }
            return $final_result;
        }
    }

    public static function __callStatic($name, $arguments)
    {
        $mm = new static();
        if (method_exists($mm->mqb, $name)) {
            return call_user_func_array([$mm->mqb, $name], $arguments);
        }
    }

    public function __get($name)
    {
        $name = strtolower($name);
        if (in_array($name, array_map(function ($element) {
            return strtolower($element);
        }, array_merge($this->base_fields, $this->fields, $this->meta_fields)))) {
            return $this->data[$name];
        }
        if (array_key_exists($name, $this->data)) return $this->data[$name];
    }

    public function __isset($name)
    {
        return isset($this->data[$name]);
    }

    public function __debugInfo()
    {
        return $this->data;
    }

    public function __toString()
    {
        $id = $this->render_value;
        return (string)$this->data[$id];
    }
}