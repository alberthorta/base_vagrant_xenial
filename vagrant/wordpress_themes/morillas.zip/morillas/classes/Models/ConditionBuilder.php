<?php

namespace Models;

class ConditionBuilder
{
    static function isComponent($condition)
    {
        if (count($condition) == 3) {
            if (in_array($condition[0], ['=', '<>', 'IN', 'LIKE'])) {
                return true;
            }
        }
        return false;
    }

    static function buildCondition($condition)
    {
        if ($condition[1] instanceof QueryBuilder) $condition[1] = "(" . $condition[1]->sql() . ")";
        if ($condition[2] instanceof QueryBuilder) $condition[2] = "(" . $condition[2]->sql() . ")";
        return $condition[1] . " " . $condition[0] . " " . $condition[2];
    }

    static function build($conditions)
    {
        $result = '';
        switch ($conditions[0]) {
            case 'AND':
                array_shift($conditions);
                foreach ($conditions as $key => $condition) {
                    if ($key != 0) $result .= ' AND ';
                    $result .= self::build($condition);

                }
                break;
            case 'OR':
                array_shift($conditions);
                foreach ($conditions as $key => $condition) {
                    if ($key != 0) $result .= ' OR ';
                    $result .= self::build($condition);
                }
                break;
            default:
                if (self::isComponent($conditions)) {
                    $result .= self::buildCondition($conditions);
                }
                break;
        }

        return $result;
    }
}