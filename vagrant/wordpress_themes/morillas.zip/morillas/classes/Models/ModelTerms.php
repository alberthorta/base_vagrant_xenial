<?php

namespace Models;

class ModelTerms extends ModelBase
{
    protected $valid_params = ['term_id', 'term_taxonomy'];
    protected $term_taxonomy = 'category';

    public function filter(MorillasQueryBuilder $mqb)
    {
        $mqb->distinct();
        $mqb->join('wp_term_relationships', $mqb->getTable().'.ID = wp_term_relationships.object_id', QueryBuilder::LEFT_JOIN);
        $mqb->join('wp_term_taxonomy', 'wp_term_relationships.term_taxonomy_id = wp_term_taxonomy.term_taxonomy_id', QueryBuilder::LEFT_JOIN);
        $mqb->join('wp_terms', 'wp_terms.term_id = wp_term_taxonomy.term_id', QueryBuilder::LEFT_JOIN);

        if( ($term_taxonomy = $this->getParam('term_taxonomy')) === null ) $term_taxonomy = $this->term_taxonomy;

        if( ($term_id = $this->getParam('term_id')) !== null ){
            $mqb->where("wp_term_taxonomy.taxonomy = '{$term_taxonomy}'");
            $mqb->where("wp_terms.term_id = '" .$term_id . "'");
        }

        return $mqb;
    }
}