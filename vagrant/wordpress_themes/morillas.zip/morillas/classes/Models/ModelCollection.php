<?php

namespace Models;

class ModelCollection implements \Iterator, \ArrayAccess, \Countable
{
    protected $position = 0;
    protected $values;

    public function __construct($values = [])
    {
        $this->values = $values;
    }

    public function first()
    {
        return current($this->values);
    }

    public function current()
    {
        return $this->values[$this->position];
    }

    public function next()
    {
        $this->position++;
    }

    public function key()
    {
        return $this->position;
    }

    public function valid()
    {
        return !($this->position >= count($this->values));
    }

    public function rewind()
    {
        $this->position = 0;
    }

    public function offsetExists($offset)
    {
        return isset($this->values[$offset]);
    }

    public function offsetGet($offset)
    {
        return $this->values[$offset];
    }

    public function offsetSet($offset, $value)
    {
        $this->values[$offset] = $value;
    }

    public function offsetUnset($offset)
    {
        unset($this->values[$offset]);
        $this->values = array_values($this->values);
    }

    public function count()
    {
        return count($this->values);
    }

    public function toArray()
    {
        return $this->values;
    }

    public function __get($name)
    {
        $out = [];
        foreach($this as $element) {
            $out[] = $element->$name;
        }
        return $out;
    }

    public function __toString()
    {
        $out = '';
        foreach ($this->values as $value) {
            $out .= $value . "";
        }

        return $out;
    }
}