<?php

namespace Models;

class TranslatableModel extends Model
{
    protected $element_type = 'post';

    public function __construct($options = [])
    {
        $translatable = array_shift($options);
        parent::__construct();
        $this->mqb->field("wp_icl_translations.language_code", "language_code");
        $this->mqb->join("wp_icl_translations", ConditionBuilder::build(["AND", ["=", $this->table . ".".$this->id, "wp_icl_translations.element_id"], ["LIKE", "wp_icl_translations.element_type", "'".$this->element_type."_%'"]]));
        if ($translatable !== null) {
            $this->mqb->where(ConditionBuilder::build(["=", "wp_icl_translations.language_code", "'" . $translatable . "'"]));
        }
    }
}