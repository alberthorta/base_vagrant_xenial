<?php

namespace Models;

class QueryBuilder{

    const LEFT_JOIN = 0, JOIN = 1, RIGHT_JOIN = 2, INNER_JOIN = 3;
    const DESC = 0, ASC = 1;
    const AND = 0, OR = 1;

    public $built_model = "Models\\Model";
    protected $distinct = false;
    protected $fields = [];
    protected $joins = [];
    protected $where = [];
    protected $order_by = [];
    protected $group_by = [];
    protected $limit;
    protected $table;

    public function __construct() {

    }

    public function published() {
        $this->where("wp_posts.post_status='publish'");

        return $this;
    }

    public function language($language) {
        $this->where("language_code = '".$language."'");

        return $this;
    }

    public function exclude($id) {
        if(!is_array($id)) $id = [$id];
        $obj = new $this->built_model();
        $this->where($obj->getTable().".".$obj->getId()." not in (".implode(",",$id).")");

        return $this;
    }

    public function distinct($d = true) {
        $this->distinct = $d;

        return $this;
    }

    public function field($name, $as_name = null)
    {
        if($name instanceof QueryBuilder) $name = "(".$name->sql().")";
        $this->fields[] = $name. (($as_name !== null)? " AS ".$as_name : "");

        return $this;
    }

    public function join($table, $condition, $type_join = self::LEFT_JOIN, $as_name = null)
    {
        $joins = [self::LEFT_JOIN => 'LEFT JOIN ', self::JOIN => 'JOIN ', self::RIGHT_JOIN => 'RIGHT JOIN ', self::INNER_JOIN => 'INNER JOIN '];
        if($table instanceof QueryBuilder) $table = "(".$table->sql().")";
        $this->joins[] = $joins[$type_join].$table.(($as_name !== null)? " AS ".$as_name : " ")." ON ".$condition;

        return $this;
    }

    public function where($condition, $type_where = self::AND)
    {
        $wheres = [self::AND => 'AND ', self::OR => 'OR '];
        $this->where[] = [$condition, $wheres[$type_where]];

        return $this;
    }

    public function first()
    {
        global $wpdb;
        $limit = $this->limit;
        $this->limit(1,0);
        $results = $wpdb->get_results($this->sql(), ARRAY_A);
        $this->limit = $limit;
        if(count($results) === 0 ) return null;

        $obj = new $this->built_model();
        $obj->setData($results[0]);

        return $obj;
    }

    public function get()
    {
        global $wpdb;
        $results = $wpdb->get_results($this->sql(), ARRAY_A);
        if(count($results) === 0 ) return new ModelCollection();

        $final_result = [];
        foreach ($results as $result) {
            $obj = new $this->built_model();
            $obj->setData($result);
            $final_result[] = $obj;
        }

        return new ModelCollection($final_result);
    }

    public function order($field, $direction = self::DESC)
    {
        $directions = [self::DESC => 'DESC ', self::ASC => 'ASC '];
        $this->order_by[] = $field." ".$directions[$direction];

        return $this;
    }

    public function limit($limit, $offset = 0)
    {
        $this->limit = ($limit !== null) ? $limit." OFFSET ".($offset===null?0:$offset) : null;

        return $this;
    }

    public function group($field)
    {
        $this->group_by[] = $field;

        return $this;
    }

    public function getTable()
    {
        return $this->table;
    }

    public function setTable($table_name, $as_name = null) {
        if($table_name instanceof QueryBuilder) $table_name = "(".$table_name->sql().")";
        $this->table = $table_name. (($as_name !== null)? " AS ".$as_name : "");
        return $this;
    }

    public function setPostTypes($post_types)
    {
        $this->where($this->table.".post_type IN ('".implode("','",$post_types)."')");
        return $this;
    }

    public function setTerm($term, $taxonomy = 'category')
    {
        return $this->setTerms([$term], $taxonomy);
    }

    public function setTerms($terms, $taxonomy = 'category')
    {
        $this->join('wp_term_relationships', $this->table.'.ID = wp_term_relationships.object_id', QueryBuilder::INNER_JOIN);
        $this->join('wp_term_taxonomy', 'wp_term_relationships.term_taxonomy_id = wp_term_taxonomy.term_taxonomy_id', QueryBuilder::INNER_JOIN);
        $this->join('wp_terms', 'wp_terms.term_id = wp_term_taxonomy.term_id', QueryBuilder::INNER_JOIN);

        $this->where("wp_term_taxonomy.taxonomy = '{$taxonomy}'");

        list($slugs, $numerics) = array_reduce($terms, function($result, $item) {
            $result[(int)is_numeric($item)][] = $item;
            return $result;
        }, [[],[]]);

        if(!empty($numerics)) $this->where("wp_terms.term_id IN (" . implode(',', $numerics) . ")");
        if(!empty($slugs)) $this->where("wp_terms.slug IN ('" . implode("','", $slugs) . "')");

        return $this;
    }

    public function sql()
    {
        $query = "SELECT ";
        if($this->distinct) $query .= "DISTINCT ";

        $query .= implode(", ", $this->fields)." ";

        $query .= "FROM ".$this->table." ";
        $query .= implode(" ", $this->joins)." ";

        if(count($this->where) > 0) {
            $query .= "WHERE ";
            foreach ( $this->where as $key => $where ) {
                if($key !== 0) $query .= $where[1]." ";
                $query .= $where[0]." ";
            }
        }
        if(count($this->group_by) > 0) $query .= "GROUP BY ".implode(", ", $this->group_by)." ";
        if(count($this->order_by) > 0) $query .= "ORDER BY ".implode(", ", $this->order_by)." ";

        if($this->limit !== null) $query .= "LIMIT ".$this->limit;

        return $query;
    }
}