<?php

namespace Views;

use Models\Model;
use Models\ModelCollection;

class View
{
    public static $rendered = false;
    protected $model;

    public function __construct(Model $model, $i = 0)
    {
        $this->model = $model;
        $this->index = $i;
    }

    static function wrap($model)
    {
        if ($model instanceof Model) {
            return new static($model);
        } else if ($model instanceof ModelCollection) {
            $c = new ModelCollection($model->toArray());
            for ($i = 0; $i < count($c); $i++) {
                $c[$i] = new static($c[$i], $i);
            }
            return $c;
        }
    }

    protected function renderScript() {
        return "";
    }

    protected function render($model)
    {
        return nl2br(print_r($model, true));
    }

    public function __toString()
    {
        $out = '';
        if(static::$rendered === false) {
            $out .= $this->renderScript();
            static::$rendered = true;
        }
        $out .= $this->render($this->model);
        return $out;
    }
}