<?php

class MorillasTemplate
{
    protected $template_file;
    protected $template_vars = [];

    public function __construct($template_name) {
        if(file_exists(MorillasTheme::singleton()->childPath('templates'.DIRECTORY_SEPARATOR.$template_name))) {
            $this->template_file = MorillasTheme::singleton()->childPath('templates'.DIRECTORY_SEPARATOR.$template_name);
        } else {
            $this->template_file = MorillasTheme::singleton()->parentPath('templates'.DIRECTORY_SEPARATOR.$template_name);
        }
    }

    public function addVar($var_name, $value) {
        $this->template_vars[$var_name] = $value;
        return $this;
    }

    public function addVars($var_array = []) {
        foreach($var_array as $key=>$value) {
            $this->addVar($key, $value);
        }
        return $this;
    }

    public static function renderTemplate($template_name, $vars = []) {
        return (new self($template_name))->addVars($vars)->renderFunction();
    }

    public function renderFunction() {
        return [$this, 'render'];
    }

    public function render() {
        foreach($this->template_vars as $key=>$value) $$key = $value;
        include($this->template_file);
    }
}