<?php

namespace MenuItem;

class SocialRenderer extends Renderer {
    public function render($nav = "") {
        $path_social_icon = is_dir(\MorillasTheme::singleton()->childPath('assets'.DIRECTORY_SEPARATOR.'image'.DIRECTORY_SEPARATOR.'socialmedia'))?
            \MorillasTheme::singleton()->childUrl('/assets/image/socialmedia'):
            \MorillasTheme::singleton()->parentUrl('/assets/image/socialmedia');
        $annex = '<ul class="social_media_menu">';
        foreach ($this->items as $item) {

            if (get_option($item) != '')
                $annex .= '<li class="social-media"><a href="' . get_option($item) . '" target="_blank" class="' . $item . '"> <img class="svg" src="' . $path_social_icon . '/' . $item . '.svg"></a></li>';

        }
        $annex .= '</ul>';
        return $nav.$annex;
    }
}