<?php

namespace MenuItem;

class Renderer {
    public $location = null;
    public $items = [];

    public function __construct($location) {
        $this->location = $location;
    }

    public function navMenuItems($nav, $args) {
        if(strtolower($args->theme_location) == strtolower($this->location)) return $this->render($nav);
        return $nav;
    }

    public function setItems($items) {
        $this->items = $items;
        return $this;
    }

    public function renderFunction() {
        return [$this, 'render'];
    }

    public function render($nav) {
        $annex = '<ul>';
        foreach ($this->items as $item) {
            if (get_option($item) != '') $annex .= '<li>'.$item.'</li>';
        }
        $annex .= '</ul>';
        return $nav.$annex;
    }
}