<?php

namespace MenuItem;

trait MorillasSocializableTheme
{
    public function addSocialMediaOptions($social_medias, Renderer $renderer = null) {
        if($renderer===null) $renderer = new SocialRenderer('Footer');
        $renderer->setItems($social_medias);

        add_filter('wp_nav_menu_items', [$renderer, 'navMenuItems'], 10, 2);
        add_action('admin_init', function() use ($social_medias) {
            foreach ($social_medias as $network) {
                register_setting('theme-options-fields-sc', $network);
            }
        });

        add_action('admin_menu', function () use ($social_medias) {
            add_submenu_page(
                'theme-options',
                'Social Network',
                'Social Network',
                'manage_options',
                'theme-op-social-network',
                \MorillasTemplate::renderTemplate('themeOptionsSettingsPageSocialMedia.template.php', ['social_media'=>$social_medias])
            );
        });
    }
}
