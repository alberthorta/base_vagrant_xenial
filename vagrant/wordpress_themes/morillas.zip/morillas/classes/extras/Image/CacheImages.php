<?php

namespace Image;

/**
 * Class CacheImages
 */
class CacheImages {
    /**
     * Cache options
     *
     * @var array
     */
    public static $options = [];

    /**
     * Sets the public folder access constants.
     *
     * @param string $public_url
     * @param string $folder
     */
    public static function setPublicFolderAccess($public_url, $folder) {
        self::$options['public_url'] = rtrim($public_url,"/");
        self::$options['folder'] = rtrim($folder,DIRECTORY_SEPARATOR);
    }

    /**
     * Caches the public file.
     *
     * @param string $key
     * @param closure $fnc
     * @return string
     */
    public static function publicFile($key, $fnc, $enabled = true) {
        $m = md5($key);
        $folder_lvl1 = substr($m, 0, 2);
        $folder_lvl2 = substr($m, 2, 2);
        if (!file_exists(self::$options['folder'] . DIRECTORY_SEPARATOR . $folder_lvl1)) {
            mkdir(self::$options['folder'] . DIRECTORY_SEPARATOR . $folder_lvl1);
        }
        if (!file_exists(self::$options['folder'] . DIRECTORY_SEPARATOR . $folder_lvl1 . DIRECTORY_SEPARATOR . $folder_lvl2)) {
            mkdir(self::$options['folder'] . DIRECTORY_SEPARATOR . $folder_lvl1 . DIRECTORY_SEPARATOR . $folder_lvl2);
        }
        $folder = self::$options['folder'] . DIRECTORY_SEPARATOR . $folder_lvl1 . DIRECTORY_SEPARATOR . $folder_lvl2 . DIRECTORY_SEPARATOR;
        $url = self::$options['public_url'] . "/" . $folder_lvl1 . "/" . $folder_lvl2 . "/";

        if (!file_exists($folder . $key) || !$enabled) {
            $image = $fnc();
            file_put_contents($folder . $key, $image->getImageBlob());
        }

        return ($url . $key);
    }

    /**
     * Clears the cached key data.
     *
     * @param string $key
     * @return bool
     */
    public static function clearCache($key) {
        $m = md5($key);
        $folder_lvl1 = substr($m, 0, 2);
        $folder_lvl2 = substr($m, 2, 2);
        if(file_exists(self::$options['folder'] . DIRECTORY_SEPARATOR . $folder_lvl1 . DIRECTORY_SEPARATOR . $folder_lvl2 . DIRECTORY_SEPARATOR . $key)) {
            return @unlink(self::$options['folder'] . DIRECTORY_SEPARATOR . $folder_lvl1 . DIRECTORY_SEPARATOR . $folder_lvl2 . DIRECTORY_SEPARATOR . $key);
        }
        return false;
    }
}