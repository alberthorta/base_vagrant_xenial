<?php

namespace Image;

/**
 * Class ImageMask
 */
class ImageMask extends Image {
    /**
     * Generates basic empty mask with white background
     * @return ImagickDraw
     */
    protected function generateBasicMaskDraw() {
        $basic_mask = new \ImagickDraw();
        $basic_mask->setStrokeOpacity(0);
        $basic_mask->setFillColor(new \ImagickPixel('white'));
        return $basic_mask;
    }

    /**
     * Generates a circle mask by giving a diametre.
     *
     * @param int $diameter
     * @return ImageMask
     */
    public static function circle($diameter) {
        $image = new self();
        $imagick = new \Imagick();
        $imagick->newPseudoImage(
            $diameter,
            $diameter,
            "canvas:transparent"
        );
        $circle = $image->generateBasicMaskDraw();
        $circle->circle(floor($diameter/2),floor($diameter/2), $diameter-1, floor($diameter/2));
        $imagick->drawImage($circle);
        $imagick->setFormat('png');
        $image->setImage($imagick);
        return $image;
    }

    /**
     * Generates an ellipse mask by giving a width and height.
     *
     * @param int $width
     * @param int $height
     * @return ImageMask
     */
    public static function ellipse($width, $height) {
        $image = new self();
        $imagick = new \Imagick();
        $imagick->newPseudoImage(
            $width,
            $height,
            "canvas:transparent"
        );
        $ellipse = $image->generateBasicMaskDraw();
        $ellipse->ellipse(floor($width/2),floor($height/2), floor($width/2)-2, floor($height/2)-2, 0, 360);
        $imagick->drawImage($ellipse);
        $imagick->setFormat('png');
        $image->setImage($imagick);
        return $image;
    }
}