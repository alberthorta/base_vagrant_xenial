<?php

namespace Image;

/**
 * Class Image
 */
class Image {
    const FROM_CENTER = 1;

    /**
     * @var Imagick
     */
    protected $image = null;

    /**
     * Image constructor.
     *
     * Protected constructor to prevent initialization with the constructor.
     */
    protected function __construct() {
    }

    /**
     * imagick setter to be used from the factories.
     *
     * @param \Imagick $image
     */
    protected function setImage(\Imagick $image) {
        $this->image = $image;
    }

    /**
     * Factory that build Image object from a file
     *
     * @param string $file_name
     * @return Image
     * @throws ImageException
     */
    public static function fromImageFile($file_name) {
        $image = new static();
        try {
            $image->setImage(new \Imagick($file_name));
        } catch(\ImagickException $e) {
            switch($e->getCode()) {
                case 435:
                    throw ImageException::CantOpenFileException($file_name);
                default:
                    throw ImageException::UnknownErrorException($e->getCode());
            }
        }

        return $image;
    }

    /**
     * Factory that build Image object from a stream
     *
     * @param $stream
     * @return Image
     * @throws ImageException
     */
    public static function fromStream($stream) {
        $image = new static();
        $imagick = new \Imagick();
        try {
            $imagick->readImageBlob((string)$stream);
        } catch(\ImagickException $e) {
            switch($e->getCode()) {
                case 1:
                    throw ImageException::ZeroBytesStreamException();
                case 420:
                    throw ImageException::InvalidImageException();
                default:
                    throw ImageException::UnknownErrorException($e->getCode());
            }
        }
        $image->setImage($imagick);
        return $image;
    }

    /**
     * Gets the with from the current image.
     *
     * @return int
     */
    public function width() {
        return $this->image->getImageWidth();
    }

    /**
     * Gets the height from the current image.
     *
     * @return int
     */
    public function height() {
        return $this->image->getImageHeight();
    }

    /**
     * Gets the Imagick resource object.
     *
     * @return Imagick
     */
    public function getImagick() {
        return $this->image;
    }

    /**
     * Check if point it's inside of the image.
     *
     * @param ImagePoint $p
     * @return bool
     */
    public function isPointValid(ImagePoint $p) {
        return $p->getX()<$this->width() && $p->getY()<$this->height();
    }

    /**
     * Crops an image giving two ImagePoint objects.
     *
     * @param ImagePoint $a
     * @param ImagePoint $b
     * @return $this
     */
    public function crop(ImagePoint $a, ImagePoint $b) {
        ImagePoint::TLBR($a, $b);
        $a->verifyItsOnImage($this);
        $b->verifyItsOnImage($this);
        $this->image->cropImage(
            ImagePoint::distanceXBetweenPoints($a, $b),
            ImagePoint::distanceYBetweenPoints($a, $b),
            $a->getX(),
            $a->getY()
        );
        return $this;
    }

    /**
     * Crops an image from the center giving a width and a height of the desired image.
     *
     * @param int $width
     * @param int $height
     * @return Image
     */
    public function cropFromCenter($width, $height) {
        $width = min($this->width()-1, $width);
        $height = min($this->height()-1, $height);
        $a = ImagePoint::on(floor($this->width()/2) - floor($width/2), floor($this->height()/2) - floor($height/2));
        $b = ImagePoint::on(floor($this->width()/2) + floor($width/2), floor($this->height()/2) + floor($height/2));
        return $this->crop($a, $b);
    }

    /**
     * Apply a circular mask to the image. The mask can be elliptical if the image it's not squared.
     *
     * @return $this
     */
    public function circularMask() {
        $this->applyTransparencyMask(ImageMask::ellipse($this->width(), $this->height()));
        $this->image->setFormat('png');
        return $this;
    }

    /**
     * Applies a transparency mask giving a ImageMask and position of the mask as imputs.
     *
     * @param Image $mask
     * @param int $apply_on_x
     * @param int $apply_on_y
     * @return $this
     */
    public function applyTransparencyMask(Image $mask, $apply_on_x = 0, $apply_on_y = 0) {
        $this->image->compositeImage($mask->getImagick(), \Imagick::COMPOSITE_COPYOPACITY,$apply_on_x,$apply_on_y,\Imagick::CHANNEL_ALL);
        $this->image->setFormat('png');
        return $this;
    }

    /**
     * Applies a transparency mask giving a ImageMask and position of the mask as imputs.
     *
     * @param Image $mask
     * @param int $apply_on_x
     * @param int $apply_on_y
     * @return $this
     */
    public function applyMask(Image $mask, $apply_on_x = 0, $apply_on_y = 0) {
        $this->image->compositeImage($mask->getImagick(), \Imagick::COMPOSITE_DEFAULT,$apply_on_x,$apply_on_y,\Imagick::CHANNEL_ALL);
        $this->image->setFormat('png');
        return $this;
    }

    /**
     * Fits the image into a new width and height box.
     *
     * @param int $new_width
     * @param int $new_height
     * @param int $filter
     * @return $this
     */
    public function fitIn($new_width, $new_height, $filter = \Imagick::FILTER_POINT) {
        $this->image->resizeImage($new_width, $new_height, $filter, 0, true);
        return $this;
    }

    /**
     * Change the aspect ratio of the image.
     *
     * @param $w
     * @param $h
     *
     * @return $this
     */
    public function aspectRatio( $w, $h ) {

        if( $w/$h === 1 ) {
            $this->cropFromCenter(min($this->width(), $this->height()), min($this->width(), $this->height()));
        } else if( $this->width()/ $this->height() > $w/$h ) {
            $this->cropFromCenter(($this->height() * $w / $h), $this->height());
        } else {
            $this->cropFromCenter($this->width(), ($this->width() * $h / $w));
        }

        return $this;
    }

    /**
     * Squeare the image with by the given side length.
     *
     * @param int $new_side
     * @param int $filter
     * @return $this
     */
    public function square($new_side, $filter = \Imagick::FILTER_POINT) {
        $min_side = min($this->width(), $this->height());
        $this->cropFromCenter($min_side, $min_side);
        $this->image->resizeImage($new_side, $new_side, $filter, 0, true);
        return $this;
    }

    /**
     * Blurs the image by given sigma and radius.
     *
     * @param float $radius
     * @param int $sigma
     * @return $this
     */
    public function blur($radius, $sigma) {
        $this->image->blurImage($radius, $sigma);
        return $this;
    }

    /**
     * Get the image blob string.
     *
     * @return string
     */
    public function getImageBlob() {
        return $this->image->getImageBlob();
    }

    /**
     * Get the base64 representation of the image (valid for img src).
     *
     * @return string
     */
    public function getBase64String() {
        return "data:".$this->image->getImageMimeType().";base64,".base64_encode($this->image->getImageBlob());
    }

    /**
     * Mirrors the image vertically.
     *
     * @return $this
     */
    public function flip() {
        $this->image->flipImage();
        return $this;
    }

    /**
     * Mirrors the image horizontally.
     *
     * @return $this
     */
    public function flop() {
        $this->image->flopImage();
        return $this;
    }

    /**
     * Sets the background color
     *
     * @param $color
     * @return $this
     */
    public function background($color) {
        $this->image->setBackgroundColor($color);
        $this->image->flattenImages();
        return $this;
    }

    /**
     * Convert to grayscale image
     *
     * @return $this
     */
    public function grayscale($b = 100, $s = 0, $h = 100) {
        $this->image->modulateImage($b, $s, $h);
        return $this;
    }

    /**
     * @param $color
     * @param $alpha
     *
     * @return $this
     */
    public function flatColorMask($color, $alpha) {
        $draw = new \ImagickDraw();

        $draw->setFillColor($color);

        if (is_float($alpha)) {
            $draw->setFillAlpha($alpha);
        }

        $geometry = $this->image->getImageGeometry();
        $width = $geometry['width'];
        $height = $geometry['height'];

        $draw->rectangle(0, 0, $width, $height);

        $this->image->drawImage($draw);

        return $this;
    }

    /**
     * @param       $color
     * @param float $alpha
     *
     * @return $this
     */
    public function colorize($color, $alpha = 0.5) {
        $this->image->colorizeImage($color, $alpha, true);

        return $this;
    }

    /**
     * Sets the output to jpg (you can also specify the quality 0 to 100).
     *
     * @param int $quality
     * @return $this
     */
    public function jpg($quality=50) {
        $this->image->setImageCompressionQuality($quality);
        $this->image->setFormat("JPEG");
        return $this;
    }

    /**
     * Sets the output to png.
     *
     * @return $this
     */
    public function png() {
        $this->image->setFormat("PNG");
        return $this;
    }
}