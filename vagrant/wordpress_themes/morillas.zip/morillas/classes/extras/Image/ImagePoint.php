<?php

namespace Image;

/**
 * Class ImagePoint
 */
class ImagePoint {

    /**
     * @var int
     */
    protected $x = 0;

    /**
     * @var int
     */
    protected $y = 0;

    /**
     * ImagePoint constructor.
     */
    protected function __construct() {
    }

    /**
     * Setter for x
     *
     * @param $x
     */
    protected function setX($x) {
        $this->x = $x;
    }

    /**
     * Setter for y
     *
     * @param $y
     */
    protected function setY($y) {
        $this->y = $y;
    }

    /**
     * Checks if point is valid and throws an exception if it's not.
     * @param $x
     * @param $y
     * @throws ImagePointException
     */
    public static function checkPoint($x,$y) {
        if($x<0 || $y<0) throw ImagePointException::InvalidPointException($x,$y);
    }

    /**
     * Factory to build a new point.
     *
     * @param int $x
     * @param int $y
     * @return ImagePoint
     * @throws ImagePointException
     */
    public static function on($x, $y) {
        ImagePoint::checkPoint($x, $y);
        $point = new self();
        $point->setX($x);
        $point->setY($y);
        return $point;
    }

    public function verifyItsOnImage(Image $img) {
        if(!$img->isPointValid($this)) throw ImagePointException::PointOutsideImage($this, $img);
        return $this;
    }

    /**
     * Recalculates the Top-Left and Bottom-Right from two points.
     *
     * @param ImagePoint $a
     * @param ImagePoint $b
     */
    public static function TLBR(ImagePoint &$a, ImagePoint &$b) {
        $_a = clone $a;
        $_b = clone $b;
        $a = ImagePoint::on(min($_a->getX(), $_b->getX()), min($_a->getY(), $_b->getY()));
        $b = ImagePoint::on(max($_a->getX(), $_b->getX()), max($_a->getY(), $_b->getY()));
    }

    /**
     * Get X distance between point $a and $b.
     *
     * @param ImagePoint $a
     * @param ImagePoint $b
     * @return int
     */
    public static function distanceXBetweenPoints(ImagePoint $a, ImagePoint $b) {
        self::TLBR($a, $b);
        return $b->getX() - $a->getX();
    }

    /**
     * Get Y distance between point $a and $b.
     *
     * @param ImagePoint $a
     * @param ImagePoint $b
     * @return int
     */
    public static function distanceYBetweenPoints(ImagePoint $a, ImagePoint $b) {
        self::TLBR($a, $b);
        return $b->getY() - $a->getY();
    }

    /**
     * Returns X coordinate.
     *
     * @return int
     */
    public function getX() {
        return $this->x;
    }

    /**
     * Returns Y coordinate.
     *
     * @return int
     */
    public function getY() {
        return $this->y;
    }

    public function sum(ImagePoint $point) {
        if($point !== null) {
            $this->x += $point->getX();
            $this->y += $point->getY();
        }
        return $this;
    }
}