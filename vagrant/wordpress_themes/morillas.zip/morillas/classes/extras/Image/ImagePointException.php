<?php

namespace Image;

/**
 * Class ImagePointException
 */
class ImagePointException extends \Exception {
    const INVALID_POINT = 1;
    const POINT_OUTSIDE_IMAGE = 2;

    /**
     * @return ImagePointException
     */
    public static function InvalidPointException($x, $y) {
        return new self("Provided point [{$x}, {$y}] is invalid.", self::INVALID_POINT);
    }

    /**
     * @return ImagePointException
     */
    public static function PointOutsideImage($point, $img) {
        return new self("Provided point [".$point->getX().", ".$point->getY()."] is outside the image.", self::POINT_OUTSIDE_IMAGE);
    }
}