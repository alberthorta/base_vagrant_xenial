<?php

namespace Image;

/**
 * Class ImageException
 */
class ImageException extends \Exception {
    const UNKNOWN_ERRROR = -1;
    const CANT_OPEN_FILE = 1;
    const ZERO_BYTES_STREAM = 2;
    const INVALID_IMAGE_FORMAT = 3;

    /**
     * @param string $file_name
     * @return ImageException
     */
    public static function CantOpenFileException($file_name = "") {
        return new self(sprintf("Can't open file \"%s\".", $file_name), self::CANT_OPEN_FILE);
    }

    /**
     * @param $error_code
     * @return ImageException
     */
    public static function UnknownErrorException($error_code) {
        return new self(sprintf("Unidentified error with code (%d).", $error_code), self::UNKNOWN_ERRROR);
    }

    /**
     * @return ImageException
     */
    public static function ZeroBytesStreamException() {
        return new self("Can't create Image from an empty stream.", self::ZERO_BYTES_STREAM);
    }

    /**
     * @return ImageException
     */
    public static function InvalidImageException() {
        return new self("Can't understand the image format.", self::INVALID_IMAGE_FORMAT);
    }
}