<?php

namespace Filters;

use Models\QueryBuilder;

class FilterComponentBase
{
    private $params = [];
    protected $valid_params = [];
    protected $filter_engine = null;
    protected $filter_name = "";

    public function __construct($filter_engine)
    {
        $this->filter_engine = $filter_engine;
        $this->filter_name = $filter_engine->getName()."_".get_called_class();
    }

    public function parseFilterParams($params)
    {
        $this->params = array_intersect_key($params, array_flip($this->valid_params));
        foreach($this->valid_params as $valid_param) {
            if(!array_key_exists($valid_param, $this->params)) $this->params[$valid_param] = null;
        }
    }

    public function getElementName() {
        return str_replace($this->filter_engine->getName()."_", "",$this->filter_name);
    }

    public function getElementId()
    {
        return md5($this->filter_name);
    }

    public function getEngineName() {
        return $this->filter_engine->getName();
    }

    public function getParams()
    {
        return $this->params;
    }

    public function getParam($name)
    {
        return $this->params[$name];
    }

    public function filter(QueryBuilder $mqb)
    {
        return $mqb;
    }

    public function render()
    {
        list($list) = func_get_args();

        $result = '<select id="'.$this->getElementId().'">';
        $result .= '<option value="all">Select</option>';
        foreach ( $list as $item ) {
            $id = $item->getId();
            $result .= '<option value="' . $item->$id . '">' . $item . '</option>';
        }
        $result .= '</select>';
        $result .= '<script>';
        $result .= "$().ready(function() {\n";
        $result .= '$("#'.$this->getElementId().'").change(function() {
            document.filters["'.$this->getEngineName().'"].setValue("'.current($this->valid_params).'", ($(this).val() == "all")? null:$(this).val());
            document.filters["'.$this->getEngineName().'"].send(
                function(response) {
                    $("#'.$this->getEngineName().'").html(response.results);
                }
            );
        });';
        $result .= "});\n";
        $result .= '</script>';
        return $result;
    }
}