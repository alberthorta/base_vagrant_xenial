<?php

namespace Filters;

class Filter
{
    protected $script_injected = false;
    protected $query_builder = null;
    protected $filters = [];
    protected $filter_objects = [];
    protected $filter_name = "";
    protected $extra_functions = [];

    public function __construct($name)
    {
        $this->filter_name = $name;
    }

    public function setQueryBuilder($query_builder)
    {
        $this->query_builder = $query_builder;
    }

    public function getQueryBuilder()
    {
        return $this->query_builder;
    }

    public function getFilters($name = null)
    {
        $this->filters = array_map(function ($element) {
            if( is_string($element) ) return new $element($this);
            else return $element;
        }, $this->filters);

        $keys = array_flip($this->filter_objects);
        if( $name !== null && array_key_exists($name,$keys) ) return $this->filters[$keys[$name]];
        return $this->filters;
    }

    public function getFilterObjects()
    {
        return $this->filter_objects;
    }

    public function addFilter($filter)
    {
        $this->filters = array_unique(array_merge($this->filters, [$filter]));
        $this->filter_objects = array_unique(array_merge($this->filter_objects, [$filter]));
    }

    public function getName()
    {
        return $this->filter_name;
    }

    public function script()
    {
        $out = "";
        if (!$this->script_injected) {
            wp_register_script(
                'filterscript' . md5($this->filter_name),
                \MorillasTheme::singleton()->parentUrl() . DIRECTORY_SEPARATOR . "assets" . DIRECTORY_SEPARATOR . "js" . DIRECTORY_SEPARATOR . "filter.js",
                [],
                false,
                false
            );
            wp_enqueue_script('filterscript' . md5($this->filter_name));
            $out .= "<script language='javascript'>\n";
            $out .= "$().ready(function() {\n";
            $out .= "new Filter('" . $this->filter_name . "','" . addslashes(get_called_class()) . "');\n";
            foreach ($this->filter_objects as $filter) {
                $out .= "document.filters['" . $this->filter_name . "'].addFilterObject('" . addslashes($filter) . "');\n";
            }
            foreach ($this->filters as $filter) {
                $params = $filter->getParams();
                foreach ($params as $param_key => $param_name) {
                    $out .= "document.filters['" . $this->filter_name . "'].addFilter('{$param_key}'" . ($param_name !== null ? ",'" . $param_name . "'" : "") . ");\n";
                }
            }
            $out .= "});\n";
            $out .= "</script>\n";
            $this->script_injected = true;
        }
        return $out;
    }

    public function process($data = [])
    {
        $filters = $this->getFilters();
        for ($i = 0; $i < count($filters); $i++) {
            $this->filters[$i]->parseFilterParams($data);
            $this->query_builder = $this->filters[$i]->filter($this->query_builder);
        }
    }

    public function render()
    {
        $out = "";
        for ($i = 0; $i < count($this->filters); $i++) {
            $out .= $this->filters[$i]->render();
        }
        return $out;
    }

    public function renderExcept($items = [])
    {
        $out = "";
        for ($i = 0; $i < count($this->filters); $i++) {
            if (!in_array($this->filters[$i]->getElementName(), $items)) {
                $out .= $this->filters[$i]->render();
            }
        }
        return $out;
    }

    public function renderOnly($items = [])
    {
        $out = "";
        for ($i = 0; $i < count($this->filters); $i++) {
            if (in_array($this->filters[$i]->getElementName(), $items)) {
                $out .= $this->filters[$i]->render();
            }
        }
        return $out;
    }

    public function results()
    {
        return $this->query_builder->get();
    }

    static function processAjaxCalls()
    {
        if (isset($_POST['mfilters']) && $_POST['mfilters'] == 1) {
            $extra_information = [];
            $base_class = stripslashes("\\" . $_POST['base_class']);
            $filter = new $base_class($_POST['filter_name']);
            $filter_objects = json_decode(stripslashes($_POST['filter_objects']), true);
            $filter_data = json_decode(stripslashes($_POST['filter_data']), true);
            foreach ($filter_objects as $filter_object) {
                $filter->addFilter($filter_object);
            }
            $filter->process($filter_data);

            foreach ($filter->extra_functions as $extra_function) {
                $extra_information = array_merge($extra_information, call_user_func([$filter, $extra_function], $filter_objects, $filter_data, $filter));
            }

            echo json_encode(array_merge(['success' => true, 'results' => (string)$filter->results()], $extra_information));
            die();
        }
    }
}