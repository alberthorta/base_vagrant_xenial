<div class="wrap">
    <h1>Google Analytics or Tag Manager</h1>
    <form method="post" action="options.php">
        <?php settings_fields( 'section-google' ); ?>
        <?php do_settings_sections( 'theme-options-google' ); ?>
        <table class="form-table">
            <tr valign="top">
                <th scope="row" style="text-transform: capitalize;">Google Anaytics</th>
                <td><input type="text" name="google-analytics" id="google-analytics" value="<?php echo get_option('google-analytics'); ?>" /></td>
            </tr>
            <tr valign="top">
                <th scope="row" style="text-transform: capitalize;">Google Tag Manager</th>
                <td><input type="text" name="google-tag-manager" id="google-tag-manager" value="<?php echo get_option('google-tag-manager'); ?>" /></td>
            </tr>
        </table>
        <p>Important: Providing that the fields Google Tag Manager and Google Analytics are full, the field Tag Manager will prevail.</p>
        <?php submit_button(); ?>
    </form>
</div>