<div class="wrap">
    <h1>Cookies</h1>
    <form method="post" action="options.php">
        <?php
        settings_fields("section");
        do_settings_sections("theme-options");
        submit_button();
        ?>
    </form>
</div>