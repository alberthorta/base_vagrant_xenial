<?php
$wpml_options = get_option( 'icl_sitepress_settings' );
$default_lang = $wpml_options['default_language'];
?>

<style>
    .plus_button {
        background: #f0f0f0 none repeat scroll 0 0;
        border: 1px solid #ddd;
        bottom: 20px;
        color: #333;
        left: 0;
        padding: 10px 20px;
        right: 0;
        text-decoration: none;
        width: 175px;
        text-align: center;
        cursor: pointer;
        display: block; }
    .plus_button:hover {
        background: #ddd; }
    .plus_button.strong_button {
        font-weight: 700;
        display: inline-block; }
    .plus_button.italic_button {
        font-style: italic;
        display: inline-block; }
    .plus_button.logo-header-button, .plus_button.logo-header-delete {
        display: inline-block; }

</style>
<div class="wrap">
    <h1>Theme Options</h1>
    <form method="post" action="options.php">
        <?php settings_fields( 'theme-options-fields' ); ?>
        <?php do_settings_sections( 'theme-options-fields' ); ?>
        <section class="logo-header">
            <h2><?php echo __('Header logo', 'morillas') ?></h2>
            <?php
            $var_logo_lang = get_option('logo-header-url-'.ICL_LANGUAGE_CODE);

            if ( $var_logo_lang != '' ){ ?>
                <input type="hidden" name="logo-header-url-<?php echo ICL_LANGUAGE_CODE; ?>" class="header_image_url" value="<?php echo esc_attr( get_option('logo-header-url-'.ICL_LANGUAGE_CODE) ); ?>"/>
                <img style="max-width: 300px;" src="<?php echo esc_attr( get_option('logo-header-url-'.ICL_LANGUAGE_CODE) ); ?>" id="header_image" class="image_preview" />
                <div class="wrapper_button">
                    <input type= "button" class="plus_button logo-header-button" name="header_image_button" value="<?php echo __('Add image', 'morillas') ?>" />
                    <input type= "button" class="plus_button logo-header-delete" name="header_image_delete" value="<?php echo __('Delete image', 'morillas') ?>" />
                </div>
            <?php } else { ?>
                <input type="hidden" name="logo-header-url-<?php echo ICL_LANGUAGE_CODE; ?>" class="header_image_url" value="<?php echo esc_attr( get_option('logo-header-url-'.$default_lang) ); ?>"/>
                <img style="max-width: 300px;" src="<?php echo esc_attr( get_option('logo-header-url-'.$default_lang) ); ?>" id="header_image" class="image_preview" />
                <div class="wrapper_button">
                    <input type= "button" class="plus_button logo-header-button" name="header_image_button" value="<?php echo __('Add image', 'morillas') ?>" />
                    <input type= "button" class="plus_button logo-header-delete" name="header_image_delete" value="<?php echo __('Delete image', 'morillas') ?>" />
                </div>
            <?php } ?>
        </section>
        <?php submit_button(); ?>
    </form>
</div>

<script type="application/javascript">

    jQuery().ready(function () {
        jQuery('.logo-header-button').live('click', function(e) {
            e.preventDefault();
            frame = wp.media({
                title : 'Add your title here',
                frame: 'post',
                multiple : false,
                library : { type : 'image'},
                button : { text : 'Add Imagen' },
            });
            frame.on('close',function(data) {
                var imageArray = [];
                images = frame.state().get('selection');
                images.each(function(image) {
                    imageArray.push(image.attributes.url);
                });

                jQuery(".header_image_url").val(imageArray);
                jQuery("#header_image").attr('src',imageArray);
            });

            frame.open();
        });

        jQuery(".logo-header-delete").live('click', function(e){
            e.preventDefault();
            jQuery(this).parent().find('#header_image').attr("src","");
            jQuery(this).parent().find('.header_image_url').attr("value","");
        });

    });

</script>