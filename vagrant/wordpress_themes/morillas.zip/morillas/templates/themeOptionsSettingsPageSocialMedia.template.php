<div class="wrap">
    <h1>Social Networks</h1>
    <form method="post" action="options.php">
        <?php settings_fields('theme-options-fields-sc'); ?>
        <?php do_settings_sections('º'); ?>
        <table class="form-table">
            <?php foreach ($social_media as $network) { ?>
                <tr valign="top">
                    <th scope="row" style="text-transform: capitalize;"><?php echo $network ?></th>
                    <td><input type="text" placeholder="<?php echo __('Social network url','morillas') ?>" name="<?php echo $network ?>"
                               value="<?php echo esc_attr(get_option($network)); ?>"/></td>
                </tr>
            <?php } ?>
        </table>
        <?php submit_button(); ?>
    </form>
</div>