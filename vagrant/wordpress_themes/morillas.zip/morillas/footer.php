<?php wp_footer();?>
<footer>
    <?php wp_nav_menu( array('container' => false, 'menu_class' => 'menu', 'theme_location' => 'Footer' )); ?>
</footer>

<!-- POLITICA DE COOKIES -->
<div id="cookies_header" class="cookies_header">
    <?php echo get_option('cookies_'.ICL_LANGUAGE_CODE); ?>
    <a id="cookie_cross" onclick="javacript: PonerCookie();">
        <svg width="34px" height="32px" viewBox="0 0 34 32" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
            <g id="Page-1" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                <g id="Group-2" transform="translate(1.000000, 0.000000)" stroke="#FFF">
                    <g id="Page-1">
                        <path d="M0.3536,0.3535 L31.8896,31.8895" id="Stroke-1"></path>
                        <path d="M31.8893,0.3536 L0.3533,31.8896" id="Stroke-3"></path>
                    </g>
                </g>
            </g>
        </svg>
    </a>
</div>

<script type="text/javascript">
    /** COOKIES **/
    $(window).on('load', function(){
        if(getCookie('<?php echo get_option('cookies_name_'.ICL_LANGUAGE_CODE); ?>')!="<?php echo get_option('cookies_variable_'.ICL_LANGUAGE_CODE); ?>"){
            $("#cookies_header").addClass('visible');
        }
    }, jQuery);

    function PonerCookie(){
        setCookie('<?php echo get_option('cookies_name_'.ICL_LANGUAGE_CODE); ?>','<?php echo get_option('cookies_variable_'.ICL_LANGUAGE_CODE); ?>',365);
        $("#cookies_header").removeClass('visible');
    }
    /** FIN COOKIES **/
</script>

</body>
</html>
