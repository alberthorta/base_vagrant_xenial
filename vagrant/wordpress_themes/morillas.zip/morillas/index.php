<?php
	get_header(); 
	global $post;
?>

<div class="page  <?php echo $post->post_name; ?>">
	
	<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
			
		<?php the_content(); ?>
			
	<?php endwhile; endif; ?>
</div>

<?php get_footer(); ?>
