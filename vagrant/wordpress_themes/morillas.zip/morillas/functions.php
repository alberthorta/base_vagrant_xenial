<?php

if(!defined('MORILLAS_FUNCTION_PARENT')) {
    define('MORILLAS_FUNCTION_PARENT','1');

    /* JS Libraries */
    add_action('wp_enqueue_scripts', function() {
        wp_deregister_script('jquery');
    });

    //Initialize the update checker.
    require 'updates'.DIRECTORY_SEPARATOR.'theme-update-checker.php';
    $example_update_checker = new MorillasThemeUpdateChecker(
        'morillas',
        'http://themes.morillas.in/info.json'
    );

    add_filter( 'http_request_host_is_external', 'allow_my_custom_host', 10, 3 );
    function allow_my_custom_host( $allow, $host, $url ) {
        if ( $host == 'themes.morillas.in' )
            $allow = true;
        return $allow;
    }

    /* CLASS CALL */
    ini_set('session.gc_maxlifetime', '10000' );

    spl_autoload_register(function ($className) {
        $className = str_replace("\\", DIRECTORY_SEPARATOR, $className);
        if (is_file(dirname(__FILE__) . DIRECTORY_SEPARATOR . 'classes' . DIRECTORY_SEPARATOR . $className . '.php')) {
            require_once dirname(__FILE__) . DIRECTORY_SEPARATOR . 'classes' . DIRECTORY_SEPARATOR . $className . '.php';
        } else if (is_file(dirname(__FILE__) . DIRECTORY_SEPARATOR . 'classes' . DIRECTORY_SEPARATOR . 'extras' . DIRECTORY_SEPARATOR . $className . '.php')) {
            require_once dirname(__FILE__) . DIRECTORY_SEPARATOR . 'classes' . DIRECTORY_SEPARATOR . 'extras' . DIRECTORY_SEPARATOR . $className . '.php';
        }
    });

    \Filters\Filter::processAjaxCalls();

    /* Call Files */
    function enqueue_style_morillas() {
        wp_enqueue_style(
            'custom_admin_css', get_template_directory_uri().'/style.css'
        );
    }
    add_action('wp_enqueue_scripts', 'enqueue_style_morillas');

    function enqueue_external_lib_script($name, $path, $dependencies = [], $ver = '1.0', $on_footer = true) {
        add_action('wp_enqueue_scripts', function () use ($name, $path, $dependencies, $ver, $on_footer){
            wp_deregister_script($name);
            wp_register_script($name, get_template_directory_uri()."/assets/external/".$path, $dependencies, $ver, $on_footer);
            wp_enqueue_script($name);
        });
    }

    function enqueue_external_lib_css($name, $path) {
        add_action('wp_enqueue_scripts', function () use ($name, $path) {
            wp_enqueue_style($name, get_template_directory_uri()."/assets/external/".$path);
        });
    }

    define("AUTOLOAD_DEPENDENCIES", true);
    define("ON_FOOTER", true);

    function enqueue_external_lib($name, $ver='last', $on_footer = true, $autoload_dependencies = false) {
        if($ver === 'last') {
            $d = dir($base_dir = (dirname(__FILE__).DIRECTORY_SEPARATOR.'assets'.DIRECTORY_SEPARATOR.'external'.DIRECTORY_SEPARATOR.$name));
            $versions = [];
            while (false !== ($entry = $d->read())) {
                if($entry!='.' && $entry!='..' && is_dir($base_dir.DIRECTORY_SEPARATOR.$entry)) {
                    $versions[] = $entry;
                }
            }
            $d->close();
            sort($versions);
            $ver = array_pop($versions);
        }
        require_once(dirname(__FILE__).DIRECTORY_SEPARATOR."assets".DIRECTORY_SEPARATOR."external".DIRECTORY_SEPARATOR.$name.DIRECTORY_SEPARATOR.$ver.DIRECTORY_SEPARATOR."_{$name}.php");
    }

    function enqueue_child_script($script_name, $injections = [], $dependencies = ['jquery'], $on_footer = true) {
        add_action('wp_enqueue_scripts', function () use ($injections, $script_name, $dependencies, $on_footer) {
            $script_name_code = preg_replace('/([^a-zA-Z0-9_]+)/','_',$script_name);
            $script_name_code = trim(preg_replace('/(_+)/','_',$script_name_code),"_");
            wp_register_script('morillas_script_'.$script_name_code, get_stylesheet_directory_uri() . '/assets/js/'.$script_name, $dependencies, '1.0', $on_footer);
            wp_localize_script('morillas_script_'.$script_name_code, 'morillas_script_'.$script_name_code, $injections);
            wp_enqueue_script('morillas_script_'.$script_name_code);
        });
    }

    function enqueue_admin_child_script($script_name, $injections = [], $dependencies = ['jquery'], $on_footer = true) {
        add_action('admin_enqueue_scripts', function () use ($injections, $script_name, $dependencies, $on_footer) {
            $script_name_code = preg_replace('/([^a-zA-Z0-9_]+)/','_',$script_name);
            $script_name_code = trim(preg_replace('/(_+)/','_',$script_name_code),"_");
            wp_register_script('morillas_script_'.$script_name_code, get_stylesheet_directory_uri() . '/assets/js/'.$script_name, $dependencies, '1.0', $on_footer);
            wp_localize_script('morillas_script_'.$script_name_code, 'morillas_script_'.$script_name_code, $injections);
            wp_enqueue_script('morillas_script_'.$script_name_code);
        });
    }

    function enqueue_child_style($stylesheet = 'morillas.css') {
        add_action('wp_enqueue_scripts', function () use ($stylesheet) {
            wp_enqueue_style('custom_morillas_css', get_stylesheet_directory_uri().'/assets/css/'.$stylesheet);
        }, 100);
    }

    function enqueue_parent_script($script_name, $injections = []) {
        add_action('wp_enqueue_scripts', function () use ($injections, $script_name) {
            $script_name_code = preg_replace('/([^a-zA-Z0-9_]+)/','_',$script_name);
            $script_name_code = trim(preg_replace('/(_+)/','_',$script_name_code),"_");
            wp_register_script('morillas_script_'.$script_name_code, get_template_directory_uri() . '/assets/js/'.$script_name, array('jquery'), '1.0', true);
            wp_localize_script('morillas_script_'.$script_name_code, 'morillas_script_'.$script_name_code, $injections);
            wp_enqueue_script('morillas_script_'.$script_name_code);
        });
    }

    function enqueue_admin_child_style($stylesheet = 'morillas.css') {
        add_action('admin_enqueue_scripts', function () use ($stylesheet) {
            wp_enqueue_style('morillas_admin_style_'.$stylesheet, get_stylesheet_directory_uri().'/assets/css/'.$stylesheet);
        }, 100);
    }

    function enqueue_admin_parent_script($script_name, $injections = [], $dependencies = ['jquery']) {
        add_action('admin_enqueue_scripts', function () use ($injections, $script_name, $dependencies) {
            $script_name_code = preg_replace('/([^a-zA-Z0-9_]+)/','_',$script_name);
            $script_name_code = trim(preg_replace('/(_+)/','_',$script_name_code),"_");
            wp_register_script('morillas_script_'.$script_name_code, get_template_directory_uri() . '/assets/js/'.$script_name, $dependencies, '1.0', true);
            wp_localize_script('morillas_script_'.$script_name_code, 'morillas_script_'.$script_name_code, $injections);
            wp_enqueue_script('morillas_script_'.$script_name_code);
        });
    }

    function custom_login_page($login_page_name = 'Login page') {
        add_action('login_head', function() {
            $login_theme = get_stylesheet_directory_uri().'/assets/css/login.css';
            $login_theme = str_replace(get_site_url(), $_SERVER['DOCUMENT_ROOT'], $login_theme);

            if( file_exists( $login_theme ) ){
                wp_enqueue_style( 'login_css',  get_stylesheet_directory_uri().'/assets/css/login.css' );
            }else{
                wp_enqueue_style( 'login_css',  get_template_directory_uri() . '/assets/css/login.css' );
            }
        });

        add_filter('login_headerurl', function() {
            return get_bloginfo( 'url' );
        });

        add_filter( 'login_headertitle', function() use ($login_page_name) { return $login_page_name; });
    };

    function load_favicons($project_title) {
        $favicon4admin = function() use ($project_title) {
            if(is_dir(str_replace(get_site_url(), $_SERVER['DOCUMENT_ROOT'], get_stylesheet_directory_uri().'/assets/image/favicon'))) {
                echo '<link rel="apple-touch-icon" sizes="180x180" href="' . esc_url(get_stylesheet_directory_uri()) . '/assets/image/favicon/apple-touch-icon.png">
                      <link rel="icon" type="image/png" href="' . esc_url(get_stylesheet_directory_uri()) . '/assets/image/favicon/favicon-32x32.png" sizes="32x32">
                      <link rel="icon" type="image/png" href="' . esc_url(get_stylesheet_directory_uri()) . '/assets/image/favicon/favicon-16x16.png" sizes="16x16">
                      <link rel="manifest" href="' . esc_url(get_stylesheet_directory_uri()) . '/assets/image/favicon/manifest.json">
                      <link rel="mask-icon" href="' . esc_url(get_stylesheet_directory_uri()) . '/assets/image/favicon/safari-pinned-tab.svg" color="#5bbad5">
                      <link rel="shortcut icon" href="' . esc_url(get_stylesheet_directory_uri()) . '/assets/image/favicon/favicon.ico">
                      <meta name="apple-mobile-web-app-title" content="' . $project_title . '">
                      <meta name="application-name" content="' . $project_title . '">
                      <meta name="msapplication-TileColor" content="#ffffff">
                      <meta name="msapplication-TileImage" content="' . esc_url(get_stylesheet_directory_uri()) . '/assets/image/favicon/mstile-144x144.png">
                      <meta name="msapplication-config" content="' . esc_url(get_stylesheet_directory_uri()) . '/assets/image/favicon/browserconfig.xml">
                      <meta name="theme-color" content="#ffffff">';
            }
        };
        add_action( 'login_head', $favicon4admin);
        add_action( 'admin_head', $favicon4admin);
    }

    add_action('admin_enqueue_scripts', function() {
        if(file_exists(str_replace(get_site_url(), $_SERVER['DOCUMENT_ROOT'], get_stylesheet_directory_uri().DIRECTORY_SEPARATOR.'assets'.DIRECTORY_SEPARATOR.'js'.DIRECTORY_SEPARATOR.'admin_script.js'))) {
            wp_enqueue_script(
                'custom_admin_script',
                get_stylesheet_directory_uri() . '/assets/js/admin_script.js',
                array('jquery')
            );
        }
        if(file_exists(str_replace(get_site_url(), $_SERVER['DOCUMENT_ROOT'], get_stylesheet_directory_uri().DIRECTORY_SEPARATOR.'assets'.DIRECTORY_SEPARATOR.'css'.DIRECTORY_SEPARATOR.'admin_style.css'))) {
            wp_enqueue_style(
                'custom_admin_css',
                get_stylesheet_directory_uri() . '/assets/css/admin_style.css'
            );
        }
    });

    function set_language_locale($language)
    {
        $language_locale = [
            'ca' => 'ca_ES.UTF-8',
            'es' => 'es_ES.UTF-8',
            'en' => 'en_GB.UTF-8',
            'ar' => 'ar_SA.UTF-8'
        ];
        if ( isset($language) && array_key_exists($language, $language_locale) ) {
            $language = $language_locale[$language];
        } else {
            $language = 'en_GB.UTF-8';
        }
        putenv("LANG=$language");
        setlocale(LC_ALL, $language);
        setlocale(LC_TIME, $language);
    }


    /*  Menus  */
    add_theme_support( 'menus' );

    function add_social_media_menu($social_media, $location = ''){
        add_filter('wp_nav_menu_items', function ($nav, $args) use ($social_media, $location) {
            if (is_dir(str_replace(get_site_url(), $_SERVER['DOCUMENT_ROOT'], get_stylesheet_directory_uri() .DIRECTORY_SEPARATOR. 'assets'.DIRECTORY_SEPARATOR.'image'.DIRECTORY_SEPARATOR.'socialmedia'))) {
                $path_social_icon = get_stylesheet_directory_uri() . '/assets/image/socialmedia';
            } else {
                $path_social_icon = get_template_directory_uri() . '/assets/image/socialmedia';
            }
            $social = '';

            $social .= '<ul class="social_media_menu">';
            foreach ($social_media as $network) {

                if (get_option($network) != '')
                    $social .= '<li class="social-media"><a href="' . get_option($network) . '" target="_blank" class="' . $network . '"> <img class="svg" src="' . $path_social_icon . '/' . $network . '.svg"></a></li>';

            }
            $social .= '</ul>';

            if ($args->theme_location == $location) return $nav.$social;
            return $nav;
        }, 10, 2);
    }


    /* SOCIAL MEDIA */
    function register_theme_options_social_networks($social_media) {
        add_action( 'admin_init', function () use ($social_media){
            foreach ($social_media as $network) {
                register_setting('theme-options-fields-sc', $network);
            }
        });
    }
    /* SOCIAL MEDIA */

    /* COOKIES */
    function display_cookies_law()
    {
        if (ICL_LANGUAGE_CODE != null && (ICL_LANGUAGE_CODE !="")){
            $settings = array('wpautop'=>false);
            $cookies = get_option('cookies_'.ICL_LANGUAGE_CODE);
            ob_start();
            wp_editor($cookies,'cookies_'.ICL_LANGUAGE_CODE,$settings);
            $html = ob_get_contents();
            ob_end_clean();
            echo $html;

        }else{
            $settings = array('wpautop'=>false);
            $cookies = get_option('cookies');
            ob_start();
            wp_editor($cookies,'cookies',$settings);
            $html = ob_get_contents();
            ob_end_clean();
            echo $html;
        }
    }
    function display_cookies_variable()
    {
        ?>
        <input type="text" name="cookies_variable_<?php echo ICL_LANGUAGE_CODE ?>" id="cookies_variable" value="<?php echo get_option('cookies_variable_'.ICL_LANGUAGE_CODE); ?>" />
        <?php
    }

    function display_cookies_name()
    {
        ?>
        <input type="text" name="cookies_name_<?php echo ICL_LANGUAGE_CODE ?>" id="cookies_name" value="<?php echo get_option('cookies_name_'.ICL_LANGUAGE_CODE); ?>" />
        <?php
    }
    /* COOKIES */

    function display_theme_panel_fields()
    {
        if (ICL_LANGUAGE_CODE != null && (ICL_LANGUAGE_CODE !="")){
            add_settings_section("section", "Settings", null, "theme-options");
            /* COOKIES */
            add_settings_field("cookies_text", "Cookies Text", "display_cookies_law", "theme-options", "section");
            add_settings_field("cookies_variable", "Cookies Variable", "display_cookies_variable", "theme-options", "section");
            add_settings_field("cookies_name", "Cookies Name", "display_cookies_name", "theme-options", "section");
            register_setting("section", "cookies_".ICL_LANGUAGE_CODE);
            register_setting("section", "cookies_variable_".ICL_LANGUAGE_CODE);
            register_setting("section", "cookies_name_".ICL_LANGUAGE_CODE);
            /* COOKIES */

            /* ANALYTICS */
            add_settings_field("google-analytics", "Google Analytics", "google-analytics", "theme-options-google", "section-google");
            add_settings_field("google-tag-manager", "Google Tag Manager", "google-tag-manager", "theme-options-google", "section-google");
            register_setting("section-google", "google-analytics");
            register_setting("section-google", "google-tag-manager");
            /* ANALYTICS */

        }else{
            add_settings_section("section", "Settings", null, "theme-options");
            /* COOKIES */
            add_settings_field("cookies_text", "Cookies Text", "display_cookies_law", "theme-options", "section");
            add_settings_field("cookies_variable", "Cookies Variable", "display_cookies_variable", "theme-options", "section");
            add_settings_field("cookies_name", "Cookies Name", "display_cookies_name", "theme-options", "section");
            register_setting("section", "cookies");
            register_setting("section", "cookies_variable");
            /* COOKIES */

            /* ANALYTICS */
            add_settings_field("google-analytics", "Google Analytics", "google-analytics", "theme-options-google", "section-google");
            add_settings_field("google-tag-manager", "Google Tag Manager", "google-tag-manager", "theme-options-google", "section-google");
            register_setting("section-google", "google-analytics");
            register_setting("section-google", "google-tag-manager");
            /* ANALYTICS */
        }
    }
    add_action("admin_init", "display_theme_panel_fields");

    /*  SVG  */
    function cc_mime_types($mimes) {
        $mimes['svg'] = 'image/svg+xml';
        return $mimes;
    }
    add_filter('upload_mimes', 'cc_mime_types');

    add_action( 'admin_enqueue_scripts', function() {
        wp_enqueue_media();
    });

    /* ADD FEATURED IMAGE */
    function load_wp_media_files()
    {
        wp_enqueue_media();
    }
    add_action('admin_enqueue_scripts', 'load_wp_media_files');
    add_theme_support('post-thumbnails');
} else {
    MorillasTheme::singleton()->loadParentShortcodes();
    MorillasTheme::singleton()->loadChildShortcodes();
}