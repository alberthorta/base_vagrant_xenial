<?php get_header(); ?>
<div id="page-wrap" class="blog-fullwidth container">
	<div id="content" class="columns content-padding">
		<h1 class="error-404 title-light-large vm">404 ERROR</h1>
		<h2 class="title-bold-small vm-m">Sorry! The page you're looking for cannot be found.</h2>
		<ul class="vm">
			<li class="vm-xs">If you wrote the URL straight on the address bar, please double check it to make sure the path is correct.</li>
			<li class="vm-xs">Go back to the main page of <a href="<?php echo get_home_url().'">'. $blog_title = get_bloginfo( 'name' ) ?></a> and locate the document using the navigation links.</li>
			<li class="vm-xs">Press de “back” button on the browser and try with another link.</li>
		</ul>
	</div>
</div>
<?php get_footer(); ?>