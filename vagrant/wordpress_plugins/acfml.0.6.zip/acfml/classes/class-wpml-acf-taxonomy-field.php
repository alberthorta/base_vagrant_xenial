<?php

class WPML_ACF_Taxonomy_Field extends WPML_ACF_Field {

}
