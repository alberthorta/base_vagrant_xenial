<?php

class WPML_ACF_Relationship_Field extends WPML_ACF_Field {

}
